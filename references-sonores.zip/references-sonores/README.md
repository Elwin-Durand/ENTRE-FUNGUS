N33T – Sentinel
Inspiration plus spécifique pour le sound design.
https://soundcloud.com/equitycollective/sentinel?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing

PRISM – HUESHIFT
Sound design Général
https://soundcloud.com/wearesilkenwood/prism-hueshift?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing

Skybreak – Wildfire
Inspiration générale pour le vibe (sans les vocals)
https://soundcloud.com/disciple/wildfire?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing

Skybreak – River Spirit
0 : 00 -  0 : 11 Inspiration directe (Les bells avec beaucoup de reverb. Les sons superposés ajoutent)
https://soundcloud.com/disciple/riverspirit?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing

Lament - (feat Lunanescence)
Inspiration générale
https://soundcloud.com/patchstep/lament?utm_source=clipboard&utm_medium=text&utm_campaign=social_sharing